package com.example.editodevideosproyecto;


import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {
    private static final int REQUEST_CODE_PICK_VIDEO = 1;
    private boolean reproduce = false;
    private boolean video = true;
    private ImageView importButton;
    private ImageView importVideoButton;
    private ImageView importImageButton;
    private ImageView importSoundButton;
    private VideoView videoview;
    private String path;
    private RecyclerView lista_frames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Poner un texto para nombrar la duracion del video
        TextView textDuracion = findViewById(R.id.Duracion);


        videoview=(VideoView) findViewById(R.id.video_view);
        path = "android.resource://" + getPackageName() + "/" + R.raw.videoskin;
        videoview.setVideoURI(Uri.parse(path));
        lista_frames = findViewById(R.id.List_frames);
        //Para pruebas
        listaFrames(Uri.parse(path));



        /**
         * Importar Boton
         */
        importButton = findViewById(R.id.importButton);
        importButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showOptions(view);
            }
        });

        /**
         * PESTAÑA
         * Botones de importacion
         */

        /**
         * IMPORTAR VIDEO
         */
        importVideoButton = findViewById(R.id.importVideo);
        importVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickVideoFromGallery();
            }
        });
        /**
         * IMPORTAR IMAGEN
         */
        importImageButton = findViewById(R.id.importImage);
        importImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Seleccionar una imagen
            }
        });
        /**
         * IMPORTAR SONIDO
         */
        importSoundButton = findViewById(R.id.importSound);
        importSoundButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Seleccionar un sonido
            }
        });

        /**
         * Reproducir el video Boton
         */
        ImageView playButton = findViewById(R.id.playButton);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VideoView videoView = findViewById(R.id.video_view);
                //Si no hay ningun video entonces avisa al usuario de que no hay ninguno y que lo importe
                if (video == false){
                    reproduce = false;
                    Toast.makeText(MainActivity.this, "No hay ningun video", Toast.LENGTH_SHORT).show();
                }else {


                    //Si esta reproduciendo el video y pulsamos entonces cambia la imagen y pausalo
                    if (reproduce == true) {
                        playButton.setImageResource(R.drawable.boton_de_play);
                        reproduce = false;
                        videoView.pause();
                    } else { //Si no esta reproduciendo el video cambia la imagen del boton y reanudalo
                        reproduce = true;
                        playButton.setImageResource(R.drawable.pausa);
                        videoView.start();
                    }
                }

            }
        });

        //VideoView en el que se vera el video
        VideoView videoView = findViewById(R.id.video_view);
        //Barra de duracion del video
        SeekBar progressSeekBar = findViewById(R.id.progressSeekBar);



        /**
         * Barra de duracion del video
         */
        // Configurar el OnSeekBarChangeListener
        progressSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    // Si el usuario cambió la posición del SeekBar, mover el video a esa posición
                    videoView.seekTo(progress);
                    lista_frames.smoothScrollToPosition(progress);
                    textDuracion.setText(Math.round(progress/1000) + "/" + Math.round(videoView.getDuration()/1000));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Detener la reproducción del video mientras el usuario cambia la posición del SeekBar
                if (reproduce == true){
                    videoView.pause();
                }
                else{
                    videoView.start();
                }

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Continuar la reproducción del video después de que el usuario cambie la posición del SeekBar
                if (reproduce == true){

                    videoView.start();
                }
                else{
                    videoView.pause();
                }
            }
        });
/**
 * VIDEOVIEW
 */
// Configurar un OnPreparedListener para el VideoView
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // Obtener la duración del video y actualizar el máximo del SeekBar
                int duration = videoView.getDuration();
                progressSeekBar.setMax(duration);


                // Iniciar la reproducción del video
                // videoView.start();
                if (reproduce == true){

                    videoView.start();
                }
                else{
                    videoView.pause();
                }
            }
        });

// Configurar un OnCompletionListener para el VideoView
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // Cuando el video termina, detener la reproducción y reiniciar desde el principio
                videoView.seekTo(videoView.getDuration()-1);
                progressSeekBar.setProgress(videoView.getDuration()-1);
                lista_frames.smoothScrollToPosition(videoView.getDuration()-1);
                videoView.pause();

            }
        });

// Actualizar el progreso del SeekBar mientras se reproduce el video
        Runnable updateSeekBar = new Runnable() {
            @Override
            public void run() {
                int currentPosition = videoView.getCurrentPosition();
                progressSeekBar.setProgress(currentPosition);
                progressSeekBar.postDelayed(this, 100);
                lista_frames.smoothScrollToPosition(currentPosition/1000);
                /**
                 * Poner la duracion del video y de lo que lleva mientras se reproduce
                 */
                textDuracion.setText(Math.round(currentPosition/1000) + "/" + Math.round(videoView.getDuration()/1000));

            }
        };
        progressSeekBar.postDelayed(updateSeekBar, 100);

    }

    /**
     * Funcion de escoger un video de la galeria y reproducirlo
     */
    private void pickVideoFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        intent.setType("video/*");
        startActivityForResult(intent, REQUEST_CODE_PICK_VIDEO);
    }



    // Este método es llamado cuando el usuario ha seleccionado un video de la galería
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            String[] projection = { MediaStore.Video.Media.DATA };
            Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
            cursor.moveToFirst();
            String filePath = cursor.getString(column_index);
            cursor.close();
            video = true;

            VideoView videoView = findViewById(R.id.video_view);
            videoView.setVideoURI(uri);

            listaFrames(uri);



            if (reproduce == true) {
                videoView.pause();
            } else {
                videoView.start();
            }
        }
    }

    public void listaFrames(Uri videoURI)   {
        //para hacer pruebas rapidas
        videoURI = Uri.parse("android.resource://" + getPackageName() +"/"
                +R.raw.videoskin);
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(this, videoURI);
        Bitmap bitmap = retriever
                .getFrameAtTime(100000,MediaMetadataRetriever.OPTION_PREVIOUS_SYNC);
        Drawable drawable = new BitmapDrawable(getResources(), bitmap);

        // Obtener la duración del video en milisegundos
        String durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        long duration = Long.parseLong(durationStr);
        List<Bitmap> frames= new ArrayList<Bitmap>();
// Obtener el frame cada 1000 milisegundos (1 segundo)
        for (long timeUs = 0; timeUs < duration * 1000; timeUs += 1000000) {
            Bitmap frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_PREVIOUS_SYNC);
            frames.add(frame);
            // Aquí puedes hacer lo que quieras con el frame (guardarlo en una lista, mostrarlo en una vista, etc.)
        }



        FrameListAdapter adapter = new FrameListAdapter(this, frames);
        lista_frames.setAdapter(adapter);
        lista_frames.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

    }

    /**
     * Ver opciones de importar el video
     * @param view
     */
    public void showOptions(View view) {
        ConstraintLayout optionsLayout = findViewById(R.id.options_layout);
        if (optionsLayout.getVisibility() == View.VISIBLE){
            optionsLayout.setVisibility(View.INVISIBLE);
        }
        else{
            optionsLayout.setVisibility(View.VISIBLE);
        }

    }
}

//diseño: #8D8D8D color botones
/**
 * Obligar a orientacion horizontal: https://codigofacilito.com/articulos/orientacion_android
 * Quitar cabecera de aplicacion: https://es.stackoverflow.com/questions/8237/como-quitar-la-actionbar-toolbar-de-mi-aplicaci%C3%B3n-android
 * Centrar los componentes de la interfaz: https://es.stackoverflow.com/questions/516384/centrar-linearlayout-en-la-pantalla-del-dispositivo
 * Github
 * Poner los frames de los videos: https://www.geeksforgeeks.org/mediametadataretriever-class-in-android-with-examples/
 * Poner un recyclerview: https://es.stackoverflow.com/questions/58343/c%C3%B3mo-crear-un-listview-en-horizontal
 */