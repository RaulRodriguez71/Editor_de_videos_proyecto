package com.example.pixelize;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class PreviewActivity extends AppCompatActivity {

    VideoView videoView;

    private static final String FILEPATH = "filePath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        videoView = findViewById(R.id.videoView);

        String filePath = getIntent().getStringExtra(FILEPATH);

        videoView.setVideoURI(Uri.parse(filePath));

        MediaController mediaController = new MediaController(this);

        videoView.setMediaController(mediaController);

        videoView.start();
    }
}