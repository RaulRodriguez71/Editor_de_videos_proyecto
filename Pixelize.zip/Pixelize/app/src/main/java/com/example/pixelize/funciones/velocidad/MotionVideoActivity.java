package com.example.pixelize.funciones.velocidad;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.funciones.mostrar.PreviewActivity;
import com.example.pixelize.R;
import com.xw.repo.BubbleSeekBar;

import java.io.File;
import java.util.Arrays;
import android.Manifest;

public class MotionVideoActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 1;
    Uri uri;
    VideoView videoView;
    ImageView imageView;
    BubbleSeekBar bubbleSeekBar;
    boolean isPlaying = false;
    int currentSpeed;

    File dest;
    String filePrefix;
    String original_path;
    private String filePath;
    String[] command;
    ProgressDialog progressDialog;

    String type;

    private static final String FILEPATH = "filePath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slow_motion);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (type != null && type.equals("slowmotion")){
            MotionVideoActivity.this.setTitle("RALENTIZAR VIDEO");
        }else {
            MotionVideoActivity.this.setTitle("ACELERAR VIDEO");
        }

        // Obtener referencias a los elementos de la interfaz de usuario
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.pause);
        bubbleSeekBar = findViewById(R.id.bubbleSeekBar);
        progressDialog = new ProgressDialog(this);

        Intent i = getIntent();

        if (i != null) {
            // Obtener la URI del video seleccionado
            String imagePath = i.getStringExtra("uri");
            type = i.getStringExtra("type");
            uri = Uri.parse(imagePath);
            isPlaying = true;
            // Establecer la URI del video en el VideoView y comenzar la reproducción

            videoView.setVideoURI(uri);
            videoView.start();
        }

        // Configurar el evento click para el botón de pausa/reproducir
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPlaying) {
                    imageView.setImageResource(R.drawable.boton_de_play);
                    videoView.pause();
                    isPlaying = false;
                } else {
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa);
                    isPlaying = true;
                }
            }
        });

        // Configurar el listener para el evento de preparación del VideoView
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // Comenzar la reproducción del video
                videoView.start();

                // Configurar el listener para el evento de cambio de progreso en el BubbleSeekBar
                bubbleSeekBar.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
                    @Override
                    public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {

                    }

                    @Override
                    public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat) {

                    }

                    @Override
                    public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int progress, float progressFloat, boolean fromUser) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.delete(0, stringBuilder.length());
                        stringBuilder.append(progress);
                        currentSpeed = progress;
                    }
                });
            }
        });
    }
    /**
     * Ajustar la velocidad de reproducción del video.
     */
    public void slowMotionSpeed() {
        // Valor predeterminado de la velocidad
        float f2 = 2.0f;

        // Ajustar la velocidad según el valor actual de currentSpeed
        if (currentSpeed != 2) {
        } else if (currentSpeed == 3) {
            f2 = 3.0f;
        } else if (currentSpeed == 4) {
            f2 = 4.0f;
        } else if (currentSpeed == 5) {
            f2 = 5.0f;
        } else if (currentSpeed == 6) {
            f2 = 6.0f;
        } else if (currentSpeed == 7) {
            f2 = 7.0f;
        } else if (currentSpeed == 8) {
            f2 = 8.0f;
        }

        // Carpeta de destino para el video
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }

        // Extensión de archivo del video
        String fileExt = ".mp4";

        // Ruta completa del archivo de destino
        dest = new File(file, filePrefix + fileExt);

        // Obtiene la ruta real de una URI
        original_path = getRealPathFromUri(getApplicationContext(), uri);

        // Construye la cadena de filtro para ajustar la velocidad
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("setpts=");
        stringBuilder.append(f2);
        stringBuilder.append("PTS");

        // Ruta del archivo de destino
        filePath = dest.getAbsolutePath();

        // Comandos para ejecutar FFmpeg
        command = new String[]{"-y", "-i", original_path, "-filter_complex", "[0:v]setpts=2.0*PTS[v];[0:a]atempo=0.5[a]", "-map", "[a]", "-b:v", "2097k", "-r", "60", "-vcodec", "mpeg4", filePath};

        // Ejecuta el comando de FFmpeg
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Si el permiso no ha sido concedido, solicitarlo al usuario
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Mostrar una explicación al usuario sobre por qué se necesita el permiso (opcional)
                // Puedes mostrar un diálogo o una vista informativa aquí para proporcionar una explicación al usuario
            }
            // Solicitar el permiso al usuario
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE);
        } else {
            // El permiso ya ha sido concedido, puedes realizar la operación que requiere el permiso
            // Aquí puedes llamar al método que ejecuta el código para acceder al archivo
            execFFmpegBinary(command);
        }

    }

    public void fastmotionSpeed(){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }

        // Extensión de archivo del video
        String fileExt = ".mp4";

        // Ruta completa del archivo de destino
        dest = new File(file, filePrefix + fileExt);

        // Obtiene la ruta real de una URI
        original_path = getRealPathFromUri(getApplicationContext(), uri);

        // Construye la cadena de filtro para ajustar la velocidad
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("setpts=");
        stringBuilder.append("PTS");

        // Ruta del archivo de destino
        filePath = dest.getAbsolutePath();

        // Comandos para ejecutar FFmpeg
        command = new String[]{"-y", "-i", original_path, "-filter_complex", "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]", "-map", "[v]", "-map", "[a]", "-b:v", "2097k","-r","60", "-vcodec", "mpeg4", filePath};

        // Ejecuta el comando de FFmpeg
        execFFmpegBinary(command);
    }

    /**
     * Obtiene la ruta real de una URI.
     *
     * @param context     Contexto de la aplicación
     * @param contentUri  URI del contenido
     * @return Ruta real del contenido
     */
    private String getRealPathFromUri(Context context, Uri contentUri) {
        // Cursor utilizado para realizar la consulta
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Crea el menú de opciones en la actividad.
     *
     * @param menu Menú de opciones
     * @return Verdadero si se ha creado correctamente
     */
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);

        if (type != null && type.equals("slowmotion")) {
            if (oscuro == false) {
                menuItem.setIcon(R.drawable.ralentizar);
            } else {
                menuItem.setIcon(R.drawable.ralentizar_claro);
            }
        }
        else{
            if (oscuro == false) {
                menuItem.setIcon(R.drawable.acelerar);
            } else {
                menuItem.setIcon(R.drawable.acelerar_claro);
            }
        }
        return true;
    }

    /**
     * Maneja los eventos de selección de elementos del menú.
     *
     * @param item Elemento del menú seleccionado
     * @return Verdadero si el evento ha sido manejado correctamente
     */
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.Btn_funcion) {
            final android.app.AlertDialog.Builder alert = new AlertDialog.Builder(MotionVideoActivity.this);

            LinearLayout linearLayout = new LinearLayout(MotionVideoActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(50, 0, 50, 100);
            final EditText input = new EditText(MotionVideoActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            linearLayout.addView(input, lp);
            alert.setMessage("¿Que nombre quieres ponerle al video?");
            alert.setTitle("Nombre del video");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("submit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    filePrefix = input.getText().toString();

                    // Ajusta la velocidad del video
                    if (type != null && type.equals("slowmotion")){
                        slowMotionSpeed();
                    }else {
                        fastmotionSpeed();
                    }

                    finish();
                    dialogInterface.dismiss();
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Ejecuta el comando de FFmpeg de forma asíncrona.
     *
     * @param command Comando de FFmpeg a ejecutar
     */
    private void execFFmpegBinary(final String[] command) {


        progressDialog.setCancelable(false);
        progressDialog.setMessage("porfavor espere");
        progressDialog.show();

        // Configura el callback de registro de FFmpeg
        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage logMessage) {
                Log.e(Config.TAG, logMessage.getText());
            }
        });

        // Configura el callback de estadísticas de FFmpeg
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics statistics) {
                Log.d(Config.TAG, "started command : FFmpeg" + Arrays.toString(command));
            }
        });

        // Ejecuta el comando de FFmpeg de forma asíncrona
        Long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }

                // Comprueba el código de retorno de FFmpeg
                if (returnCode == RETURN_CODE_SUCCESS) {
                    // Inicia la actividad de vista previa del video
                    Intent intent = new Intent(MotionVideoActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                }
            }
        });

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

}