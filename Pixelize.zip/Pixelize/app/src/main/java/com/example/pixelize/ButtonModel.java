package com.example.pixelize;

import static com.example.pixelize.MainActivity.oscuro;

public class ButtonModel {
    private int icon;
    private String text;
    private int id;
    private int textColor;

    public ButtonModel(int icon, String text, int id) {
        this.icon = icon;
        this.text = text;
        this.id = id;
        if (oscuro) {
            textColor = android.R.color.white;
        }
        else{
            textColor = android.R.color.black;
        }
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public int getId() {
        return id;
    }

}
