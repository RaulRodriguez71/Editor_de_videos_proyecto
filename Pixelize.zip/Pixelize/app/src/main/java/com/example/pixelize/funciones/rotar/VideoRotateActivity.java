package com.example.pixelize.funciones.rotar;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;
import com.example.pixelize.funciones.silenciar.VideoMuteActivity;

import java.io.File;
import java.util.Arrays;

public class VideoRotateActivity extends AppCompatActivity {

    VideoView videoView;
    private Uri uri;
    ImageView imageView;
    Button btn_rotate180,btn_rotate90,btn_rotate270,btn_custom;

    String rotate = "90";

    boolean isPlaying = false;

    private static final String FILEPATH = "filePath";
    File dest;
    String filePrefix;
    private String filePath;
    String original_path;
    String[] command;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_rotate);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        VideoRotateActivity.this.setTitle("ROTAR VIDEO");
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);
        btn_rotate180 = findViewById(R.id.btn_rotate180);
        btn_rotate90 = findViewById(R.id.btn_rotate90);
        btn_rotate270 = findViewById(R.id.btn_rotate270);
        btn_custom = findViewById(R.id.btn_custom);


        Intent intent = getIntent();
        if (intent != null){
            String revVideo = intent.getStringExtra("uri");
            uri = Uri.parse(revVideo);
            videoView.setVideoURI(uri);
            isPlaying = true;
            videoView.start();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying){
                    imageView.setImageResource(R.drawable.boton_de_play);
                    videoView.pause();
                    isPlaying = false;
                }else{
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa);
                    isPlaying = true;
                }
            }
        });

        btn_rotate180.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate180.setEnabled(false);
                btn_rotate90.setEnabled(true);
                btn_rotate270.setEnabled(true);
                btn_custom.setEnabled(true);
                rotate = "180";
            }
        });

        btn_rotate90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate180.setEnabled(true);
                btn_rotate90.setEnabled(false);
                btn_rotate270.setEnabled(true);
                btn_custom.setEnabled(true);
                rotate = "90";
            }
        });

        btn_rotate270.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_rotate180.setEnabled(true);
                btn_rotate90.setEnabled(true);
                btn_rotate270.setEnabled(false);
                btn_custom.setEnabled(true);
                rotate = "270";
            }
        });

        btn_custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(VideoRotateActivity.this);
                dialog.setCanceledOnTouchOutside(false);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.filename_popup);
                dialog.show();
                dialog.findViewById(R.id.closePopup).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ((TextView)dialog.findViewById(R.id.Name)).setText("Enter degree");
                final EditText editText = dialog.findViewById(R.id.message);
                dialog.findViewById(R.id.send_btn).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (editText.getText().toString().length() == 0){
                            Toast.makeText(VideoRotateActivity.this, "Por favor introduce un valor entre 1 y 360", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int parseInt = Integer.parseInt(editText.getText().toString());

                        if (parseInt < 1 || parseInt > 360){
                            Toast.makeText(VideoRotateActivity.this, "Por favor introduce un valor entre 1 y 360", Toast.LENGTH_SHORT).show();
                            return;

                        }
                        rotate = editText.getText().toString();
                        dialog.dismiss();
                    }
                });
            }
        });

    }

    private String getRealPathFromUri(Context context, Uri contentUri){
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public void VideoRotateCommand(){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }
        String FileExt = ".mp4";

        dest = new File(file,filePrefix + FileExt);
        original_path = getRealPathFromUri(getApplicationContext(),uri);

        filePath = dest.getAbsolutePath();

        StringBuilder sb3 = new StringBuilder();
        sb3.append("rotate=");
        sb3.append(this.rotate);
        sb3.append("*PI/180");

        command = new String[]{"-y", "-i", original_path, "-vf", sb3.toString(), "-c:v", "libx264", "-c:a", "aac", filePath};

        ProgressDialog progressDialog;

// Mostrar ventana emergente de carga
        progressDialog = ProgressDialog.show(this, "Cargando", "Procesando el video...", true);

        execFFMpegBinary(command);
    }


    private void execFFMpegBinary(String[] command){
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Por favor, espere");
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics newStatistics) {
                Log.e(Config.TAG,String.format("frame: %d,time: %d",newStatistics.getVideoFrameNumber(),newStatistics.getTime()));
                Log.d(TAG,"Started command : ffmpeg " + Arrays.toString(command));

            }
        });
        Log.d(TAG,"Started command : ffmpeg " + Arrays.toString(command));

        long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {

                if (returnCode == RETURN_CODE_SUCCESS){
                    Log.d(Config.TAG,"finished command: ffmpeg" + Arrays.toString(command));
                    finish();
                    Intent intent = new Intent(VideoRotateActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH,filePath);
                    startActivity(intent);
                }else if (returnCode == RETURN_CODE_CANCEL){
                    Log.e(Config.TAG,"Async command execution canceled by user");
                }else{
                    Log.e(Config.TAG,String.format("Async command execution failed with returncode = %d", returnCode));
                }

            }
        });
    }
    @Override

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker,menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false){
            menuItem.setIcon(R.drawable.girar);
        }
        else {
            menuItem.setIcon(R.drawable.girar_claro);
        }
        return true;
    }


    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if (item.getItemId() == R.id.Btn_funcion){
            AlertDialog.Builder alert = new AlertDialog.Builder(VideoRotateActivity.this);

            LinearLayout linearLayout = new LinearLayout(VideoRotateActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50,0,50,100);

            EditText input = new EditText(VideoRotateActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP| Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input,lp);
            alert.setMessage("set video name");
            alert.setTitle("videoname");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Subir", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    if (!TextUtils.isEmpty(input.getText())) {
                        filePrefix = input.getText().toString();
                        VideoRotateCommand();
                        dialogInterface.dismiss();
                    }
                    else{
                        Toast.makeText(VideoRotateActivity.this, "El nombre del archivo no puede estar vacío", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }

}