package com.example.pixelize.modeloBotones;


public class ButtonModel {
    private int icon;
    private String text;
    private int id;


    public ButtonModel(int icon, String text, int id) {
        this.icon = icon;
        this.text = text;
        this.id = id;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public int getId() {
        return id;
    }



}
