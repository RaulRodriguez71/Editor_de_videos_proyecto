package com.example.pixelize.funciones.recortar;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;

import org.florescu.android.rangeseekbar.RangeSeekBar;

import java.io.File;
import java.util.Arrays;

public class TrimActivity extends AppCompatActivity {

    Uri uri;
    ImageView imageView;
    VideoView videoView;
    TextView textViewLeft;
    TextView textViewRight;
    RangeSeekBar rangeseekBar;

    private static final String FILEPATH = "filePath";

    private String filePath;

    File dest;
    String filePrefix;
    String original_path;
    int duration;
    String[] command;
    boolean isPlaying = false;
    FFmpeg ffmpeg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trim);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        TrimActivity.this.setTitle("RECORTAR VIDEO");
        imageView = findViewById(R.id.imageView);
        videoView = findViewById(R.id.videoView);
        textViewLeft = findViewById(R.id.tvLeft);
        textViewRight = findViewById(R.id.tvRight);
        rangeseekBar = findViewById(R.id.seekBar);


        Intent i = getIntent();//Obtener el video desde el main

        if (i != null) {//Si el video no es nulo
            String imagePath = i.getStringExtra("uri");
            uri = Uri.parse(imagePath);
            isPlaying = true;
            videoView.setVideoURI(uri);
            videoView.start();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    imageView.setImageResource(R.drawable.boton_de_play);

                    videoView.pause();
                    isPlaying = false;
                } else {
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa);
                    isPlaying = true;
                }
            }
        });
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoView.start();

                duration = mediaPlayer.getDuration() / 1000;

                textViewLeft.setText("00:00:00");
                textViewRight.setText(getTime(mediaPlayer.getDuration() / 1000));

                mediaPlayer.setLooping(true);

                rangeseekBar.setRangeValues(0, duration);
                rangeseekBar.setSelectedMinValue(0);
                rangeseekBar.setSelectedMaxValue(duration);
                rangeseekBar.setEnabled(true);

                rangeseekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener() {
                    @Override
                    public void onRangeSeekBarValuesChanged(RangeSeekBar bar, Object minValue, Object maxValue) {
                        videoView.seekTo((int) minValue * 1000);

                        textViewLeft.setText(getTime((int) bar.getSelectedMinValue()));
                        textViewRight.setText(getTime((int) bar.getSelectedMaxValue()));
                    }
                });
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (videoView.getCurrentPosition() >= rangeseekBar.getSelectedMaxValue().intValue() * 1000) {
                            videoView.seekTo(rangeseekBar.getSelectedMinValue().intValue() * 1000);
                        }
                    }
                }, 1000);
            }
        });

    }

    private String getTime(int seconds) {
        int hr = seconds / 3600;
        int rem = seconds % 3600;
        int mn = rem / 60;
        int sec = rem % 60;

        return String.format("%02d", hr) + " " + String.format("%02d", mn) + "" + String.format("%02d", sec);
    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false){
            menuItem.setIcon(R.drawable.cortar);
        }
        else {
            menuItem.setIcon(R.drawable.cortar_claro);
        }
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if (item.getItemId() == R.id.Btn_funcion) {
            AlertDialog.Builder alert = new AlertDialog.Builder(TrimActivity.this);

            LinearLayout linearLayout = new LinearLayout(TrimActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50, 0, 50, 100);

            EditText input = new EditText(TrimActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input, lp);
            alert.setMessage("set video name");
            alert.setTitle("videoname");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Subir", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    filePrefix = input.getText().toString();

                    trimVideo(rangeseekBar.getSelectedMinValue().intValue() * 1000, rangeseekBar.getSelectedMinValue().intValue() * 1000, filePrefix);
                    finish();
                    dialogInterface.dismiss();
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }

    private void trimVideo(int startMs, int endMs, String fileName) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }
        filePrefix = fileName;
        String FileExt = ".mp4";

        dest = new File(file, filePrefix + FileExt);

        original_path = getRealPathFromUri(getApplicationContext(), uri);

        duration = (endMs - startMs) / 1000;
        filePath = dest.getAbsolutePath();

        command = new String[]{"-ss", "" + startMs / 1000, "-y", "-i", original_path, "-t", "" + (endMs - startMs) / 1000, "-vcodec", "mpeg4", "-b:v", "20997152", "-b:a", "48000", "-ac", "48000", "-ac", "2", "-ar", "22050", filePath};
        execFFMpegBinary(command);

        // Toast.makeText(this,"Video Trimmed completado",Toast.LENGTH_SHORT).show();
    }

    private String getRealPathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void execFFMpegBinary(String[] command) {
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics newStatistics) {
                Log.e(Config.TAG, String.format("frame: %d,time: %d", newStatistics.getVideoFrameNumber(), newStatistics.getTime()));
                Log.d(TAG, "Started command : ffmpeg " + Arrays.toString(command));

            }
        });
        Log.d(TAG, "Started command : ffmpeg " + Arrays.toString(command));

        long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {

                if (returnCode == RETURN_CODE_SUCCESS) {
                    Log.d(Config.TAG, "finished command: ffmpeg" + Arrays.toString(command));

                    Intent intent = new Intent(TrimActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    Log.e(Config.TAG, "Async command execution canceled by user");
                } else {
                    Log.e(Config.TAG, String.format("Async command execution failed with returncode = %d", returnCode));
                }

            }
        });
    }
}