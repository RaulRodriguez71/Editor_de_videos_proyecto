package com.example.pixelize.modeloBotones;

import static com.example.pixelize.MainActivity.oscuro;
import static com.example.pixelize.MainActivity.selectedUri;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pixelize.R;
import com.example.pixelize.funciones.conversionVideoGif.GifConverterActivity;
import com.example.pixelize.funciones.filtros.FiltersActivity;
import com.example.pixelize.funciones.recortar.TrimActivity;
import com.example.pixelize.funciones.rotar.VideoRotateActivity;
import com.example.pixelize.funciones.silenciar.VideoSoundActivity;
import com.example.pixelize.funciones.transiciones.TransitionActivity;
import com.example.pixelize.funciones.velocidad.MotionVideoActivity;

import java.util.List;

public class ButtonAdapter extends RecyclerView.Adapter<ButtonAdapter.ViewHolder> {

    private List<ButtonModel> buttonList;

    private Context context;

    TextView texto;

    public ButtonAdapter(List<ButtonModel> buttonList, Context context) {
        this.buttonList = buttonList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.button_model_item, parent, false);
        return new ViewHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ButtonModel button = buttonList.get(position);
        holder.iconImageView.setImageResource(button.getIcon());
        holder.textView.setText(button.getText());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Manejar el evento de clic del botón
                int id = button.getId();
                switch (id) {
                    case 1:
                        // Acción para el botón "Recortar video"
                        if (selectedUri != null) {
                            // Abrir la actividad de recorte de video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, TrimActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                } else {
                    Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                }
                        break;
                    case 2:
                        // Acción para el botón "Filtros"
                        if (selectedUri != null) {
                            // Abrir la actividad de filtros de video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, FiltersActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 3:
                        // Acción para el botón "Girar video"
                        if (selectedUri != null) {
                            // Abrir la actividad de rotar el video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, VideoRotateActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 4:
                        // Acción para el botón "Acelerar video"
                        if (selectedUri != null) {
                            // Abrir la actividad de acelerar el video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, MotionVideoActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            intent.putExtra("type", "fastmotion");
                            context.startActivity(intent);


                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 5:
                        // Acción para el botón "Ralentizar video"
                        if (selectedUri != null) {
                            // Abrir la actividad de ralentizar el video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, MotionVideoActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            intent.putExtra("type", "slowmotion");
                            context.startActivity(intent);


                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 6:
                        // Acción para el botón "Silenciar video"
                        if (selectedUri != null) {
                            // Abrir la actividad de silenciar el video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, VideoSoundActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 7:
                        // Acción para el botón "Transicion video"
                        if (selectedUri != null) {
                            // Abrir la actividad de transicion el video y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, TransitionActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 8:
                        // Acción para el botón "Transicion video"
                        if (selectedUri != null) {
                            // Abrir la actividad de conversion a gif y pasar la URI del video seleccionado
                            Intent intent = new Intent(context, GifConverterActivity.class);
                            intent.putExtra("uri", selectedUri.toString());
                            context.startActivity(intent);
                        } else {
                            Toast.makeText(context, "Porfavor importa el video", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 9:
                        // Acción para el botón "Tema aplicacion"
                        //oscuro = !oscuro;


                        //notifyDataSetChanged();
                        break;

                    default:
                        Toast.makeText(context, "Parece que al desarrollador se le paso este boton", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return buttonList.size();
    }

    private void temaAplication(TextView textView) {
        if (oscuro) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.white));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        }
        System.out.println("///////////" + textView.getTextColors());


    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iconImageView;
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iconImageView = itemView.findViewById(R.id.iconImageView);
            textView = itemView.findViewById(R.id.textView);
            texto = textView;
            temaAplication(texto);

        }
    }
}
