package com.example.pixelize.funciones.filtros;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;
import com.example.pixelize.funciones.silenciar.VideoMuteActivity;
import com.xw.repo.BubbleSeekBar;

import java.io.File;
import java.util.Arrays;

public class FiltersActivity extends AppCompatActivity {

    Uri uri;
    VideoView videoView;
    ImageView imageView;
    boolean isPlaying = false;

    File dest;
    String filePrefix;
    String original_path;
    private String filePath;
    String[] command;

    private static final String FILEPATH = "filePath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filters);
        FiltersActivity.this.setTitle("MUTE VIDEO");
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);

        Intent intent = getIntent();
        if (intent != null) {
            String revVideo = intent.getStringExtra("uri");
            uri = Uri.parse(revVideo);
            videoView.setVideoURI(uri);
            isPlaying = true;
            videoView.start();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    imageView.setImageResource(R.drawable.boton_de_play);
                    videoView.pause();
                    isPlaying = false;
                } else {
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa);
                    isPlaying = true;
                }
            }
        });

    }

    public void muteVideoCommand() {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }
        String FileExt = ".mp4";

        dest = new File(file, filePrefix + FileExt);
        original_path = getRealPathFromUri(getApplicationContext(), uri);

        filePath = dest.getAbsolutePath();

        command = new String[]{"-i", original_path, "-c", "copy", "-an", filePath};
        execFFMpegBinary(command);

    }

    private String getRealPathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false) {
            menuItem.setIcon(R.drawable.mute);
        } else {
            menuItem.setIcon(R.drawable.mute_claro);
        }

        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.Btn_funcion) {
            AlertDialog.Builder alert = new AlertDialog.Builder(FiltersActivity.this);

            LinearLayout linearLayout = new LinearLayout(FiltersActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50, 0, 50, 100);

            EditText input = new EditText(FiltersActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input, lp);
            alert.setMessage("set video name");
            alert.setTitle("videoname");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Subir", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    filePrefix = input.getText().toString();
                    muteVideoCommand();
                    finish();
                    dialogInterface.dismiss();
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }


    private void execFFMpegBinary(String[] command) {
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics newStatistics) {
                Log.e(Config.TAG, String.format("frame: %d,time: %d", newStatistics.getVideoFrameNumber(), newStatistics.getTime()));
                Log.d(TAG, "Started command : ffmpeg " + Arrays.toString(command));

            }
        });
        Log.d(TAG, "Started command : ffmpeg " + Arrays.toString(command));

        long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {

                if (returnCode == RETURN_CODE_SUCCESS) {
                    Log.d(Config.TAG, "finished command: ffmpeg" + Arrays.toString(command));

                    Intent intent = new Intent(FiltersActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    Log.e(Config.TAG, "Async command execution canceled by user");
                } else {
                    Log.e(Config.TAG, String.format("Async command execution failed with returncode = %d", returnCode));
                }

            }
        });
    }
}
