package com.example.pixelize;


import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;


import android.widget.VideoView;

import com.example.pixelize.funciones.recortar.TrimActivity;
import com.example.pixelize.funciones.rotar.VideoRotateActivity;
import com.example.pixelize.funciones.silenciar.VideoMuteActivity;
import com.example.pixelize.funciones.transiciones.TransitionActivity;
import com.example.pixelize.funciones.velocidad.MotionVideoActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {

    private static final int REQUEST_CAMERA_PERMISSION = 1;
    private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 2;
    private static final int GRABAR_VIDEO = 3;
    private static final int STORAGE_PERMISSION_CODE = 4;
    public static boolean oscuro = true;
    static Uri selectedUri;
    ImageView trimButton;
    Button uploadVideoBtn;
    Button grabVideoBtn;
    VideoView videoView;
    ImageView fastButton;
    ImageView slowButton;
    ImageView filterButton;
    ImageView giroButton;
    ImageView transitionButton;
    ImageView muteButton;
    ImageView tema;

    private RecyclerView recyclerView;
    private ButtonAdapter buttonAdapter;
    private List<ButtonModel> buttonList;
    private static final String FILEPATH = "filePath";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        // Inicializar la lista de modelos de botones
        buttonList = new ArrayList<>();
        // Agregar los modelos de botones necesarios a la lista
        buttonList.add(new ButtonModel(R.drawable.cortar_claro, "Recortar video", 1));
        buttonList.add(new ButtonModel(R.drawable.filtrar_claro, "Filtros", 2));
        buttonList.add(new ButtonModel(R.drawable.girar_claro, "Girar video", 3));
        buttonList.add(new ButtonModel(R.drawable.acelerar_claro, "Acelerar video", 4));
        buttonList.add(new ButtonModel(R.drawable.ralentizar_claro, "Ralentizar video", 5));
        buttonList.add(new ButtonModel(R.drawable.mute_claro, "Quitar sonido", 6));
        buttonList.add(new ButtonModel(R.drawable.transicion_claro, "Tansicion", 7));
        buttonList.add(new ButtonModel(R.drawable.claro, "Tema", 8));


        // Configurar el RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        buttonAdapter = new ButtonAdapter(buttonList,this);
        recyclerView.setAdapter(buttonAdapter);


        //Pedir permisos para poder escribir archivos en el dispositivo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                checkPermission();
            } else {
                //Toast.makeText(MainActivity.this, "Los tienes", Toast.LENGTH_SHORT).show();
            }
        }

        if (selectedUri != null){
            videoView.setVideoURI(selectedUri);
            videoView.start();
        }



        // Fix issues of navigation and status bars
        navigationBarStatusBar();

        uploadVideoBtn = findViewById(R.id.uploadVideoBtn);
        // Configurar el evento click para el botón de subir video
        uploadVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo();
            }
        });

        grabVideoBtn = findViewById(R.id.camVideoBtn);
        // Configurar el evento click para el botón de grabar video
       grabVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               checkCameraPermission();

            }
        });



    }




    // Método para abrir la galería de videos
    public void openVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("video/*");
        startActivityForResult(intent, 100);
    }

    //Que recoger de importar el video
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
               selectedUri = data.getData();
                videoView.setVideoURI(selectedUri);
                videoView.start();
            }
            //GRABAR VIDEO CON LA CAMARA
            if (requestCode == GRABAR_VIDEO && resultCode == RESULT_OK) {
                selectedUri = data.getData();
                videoView.setVideoURI(selectedUri);
                videoView.start();
            }
        }


    }

//    //Que mandar si es ralentizar o acelerar
//    @Override
//    public void onClick(View v) {
//        if (v.getId() == R.id.slowmoVideo) {
//            Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
//            intent.putExtra(FILEPATH, selectedUri.toString());
//            intent.putExtra("type", "slowmotion");
//            startActivity(intent);
//        } else if (v.getId() == R.id.fastmotion) {
//            Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
//            intent.putExtra(FILEPATH, selectedUri.toString());
//            intent.putExtra("type", "fastmotion");
//            startActivity(intent);
//        }
  //  }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "permission granted", Toast.LENGTH_SHORT);
            } else {
                Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT);
            }
        }
    }


    //Conseguir los permisos para el funcionamiento de la aplicacion
    private void checkPermission() {

        if (!haveStoragePermission()) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, 1);
        }

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, READ_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this).setTitle("Permission needed").setMessage("Este permiso se necesita")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }


    }

    public boolean haveStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23)
            return checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        else
            return true;
    }

    /**
     * VERIFICAR PERMISOS PARA USAR LAS APLICACIONES
     */
    private void checkCameraPermission() {
        // Verificar si el permiso de cámara ha sido concedido
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Si el permiso no ha sido concedido, solicitarlo al usuario
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            startActivityForResult(takeVideoIntent, GRABAR_VIDEO);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void navigationBarStatusBar() {

        // Fix portrait issues
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Fix issues for KitKat setting Status Bar color primary
            if (Build.VERSION.SDK_INT >= 19) {
                TypedValue typedValue19 = new TypedValue();
                //MainActivity.this.getTheme().resolveAttribute(R.attr.colorPrimary, typedValue19, true);
                final int color = typedValue19.data;
                FrameLayout statusBar = (FrameLayout) findViewById(R.id.statusBar);
                statusBar.setBackgroundColor(color);
            }

            // Fix issues for Lollipop, setting Status Bar color primary dark
            if (Build.VERSION.SDK_INT >= 21) {
                TypedValue typedValue21 = new TypedValue();
                // MainActivity.this.getTheme().resolveAttribute(R.attr.colorPrimaryDark, typedValue21, true);
                final int color = typedValue21.data;
                FrameLayout statusBar = (FrameLayout) findViewById(R.id.statusBar);
                statusBar.setBackgroundColor(color);
            }
        }

        // Fix landscape issues (only Lollipop)
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (Build.VERSION.SDK_INT >= 19) {
                TypedValue typedValue19 = new TypedValue();
                //MainActivity.this.getTheme().resolveAttribute(R.attr.colorPrimary, typedValue19, true);
                final int color = typedValue19.data;
                FrameLayout statusBar = (FrameLayout) findViewById(R.id.statusBar);
                statusBar.setBackgroundColor(color);
            }
            if (Build.VERSION.SDK_INT >= 21) {
                TypedValue typedValue = new TypedValue();
                //MainActivity.this.getTheme().resolveAttribute(R.attr.colorPrimaryDark, typedValue, true);
                final int color = typedValue.data;
                FrameLayout statusBar = (FrameLayout) findViewById(R.id.statusBar);
                statusBar.setBackgroundColor(color);
            }
        }
    }


}


//diseño: #8D8D8D color botones
/**
 * Obligar a orientacion horizontal: https://codigofacilito.com/articulos/orientacion_android
 * Quitar cabecera de aplicacion: https://es.stackoverflow.com/questions/8237/como-quitar-la-actionbar-toolbar-de-mi-aplicaci%C3%B3n-android
 * Centrar los componentes de la interfaz: https://es.stackoverflow.com/questions/516384/centrar-linearlayout-en-la-pantalla-del-dispositivo
 * Github
 * como grabar videos: https://developer.android.com/training/camera/videobasics?hl=es-419
 * Poner los frames de los videos: https://www.geeksforgeeks.org/mediametadataretriever-class-in-android-with-examples/
 * Poner un recyclerview: https://es.stackoverflow.com/questions/58343/c%C3%B3mo-crear-un-listview-en-horizontal
 * ffmpeg: https://medium.com/@eeddeellee/how-to-use-ffmpeg-in-android-37b1d732c31b
 * comandos ffmpeg: https://gist.github.com/tayvano/6e2d456a9897f55025e25035478a3a50
 * Barras de decoracion de rangos: https://github.com/anothem/android-range-seek-bar
 * Barras de decoracion 2 : https://github.com/woxingxiao/BubbleSeekBar
 * libreria de ffmpeg para editar los videos: https://github.com/FFmpeg/FFmpeg
 * Cortar videos: https://www.youtube.com/watch?v=54iLwyZl30E
 * Ver los permisos de guardar archivos: https://github.com/Baseflow/flutter-permission-handler/issues/995
 * Cambiar color de la interfaz: https://www.youtube.com/watch?v=sw1WXVRUcn0
 * cambiar las imagenes: https://www.lawebdelprogramador.com/foros/Android/1626464-Cambiar-imagen-de-una-ImageView-segun-el-dato-que-muestre-un-TextView.html
 */
