package com.example.pixelize;


import static android.Manifest.permission.MANAGE_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;


import android.widget.VideoView;

import com.example.pixelize.modeloBotones.ButtonAdapter;
import com.example.pixelize.modeloBotones.ButtonModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {

    private static final int REQUEST_CAMERA_PERMISSION = 1;
    private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 2;
    private static final int GRABAR_VIDEO = 3;
    private static final int STORAGE_PERMISSION_CODE = 4;
    public static boolean oscuro = true;
    public static Uri selectedUri;

    Button uploadVideoBtn;
    Button grabVideoBtn;
    VideoView videoView;


    private RecyclerView recyclerView;
    private ButtonAdapter buttonAdapter;
    private List<ButtonModel> buttonList;
    private static final String FILEPATH = "filePath";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        // Inicializar la lista de modelos de botones
        buttonList = new ArrayList<>();
        // Agregar los modelos de botones necesarios a la lista
        buttonList.add(new ButtonModel(R.drawable.cortar_claro, "Recortar video", 1));
        buttonList.add(new ButtonModel(R.drawable.filtrar_claro, "Filtros", 2));
        buttonList.add(new ButtonModel(R.drawable.girar_claro, "Girar video", 3));
        buttonList.add(new ButtonModel(R.drawable.acelerar_claro, "Acelerar video", 4));
        buttonList.add(new ButtonModel(R.drawable.ralentizar_claro, "Ralentizar video", 5));
        buttonList.add(new ButtonModel(R.drawable.volumen_claro, "Modificar volumen", 6));
        buttonList.add(new ButtonModel(R.drawable.transicion_claro, "Tansicion", 7));
        buttonList.add(new ButtonModel(R.drawable.conversion_gif_claro, "Convertir a GIF", 8));
        //buttonList.add(new ButtonModel(R.drawable.claro, "Tema", 9));


        // Configurar el RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        buttonAdapter = new ButtonAdapter(buttonList,this);
        recyclerView.setAdapter(buttonAdapter);


        //Pedir permisos para poder escribir archivos en el dispositivo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                checkPermission();
            } else {
                //Toast.makeText(MainActivity.this, "Los tienes", Toast.LENGTH_SHORT).show();
            }

            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.MANAGE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                checkPermission();
            } else {
                //Toast.makeText(MainActivity.this, "Los tienes", Toast.LENGTH_SHORT).show();
            }
        }



        uploadVideoBtn = findViewById(R.id.uploadVideoBtn);
        // Configurar el evento click para el botón de subir video
        uploadVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo();
            }
        });

        grabVideoBtn = findViewById(R.id.camVideoBtn);
        // Configurar el evento click para el botón de grabar video
       grabVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               checkCameraPermission();

            }
        });



    }




    // Método para abrir la galería de videos
    public void openVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("video/*");
        startActivityForResult(intent, 100);
    }

    //Que recoger de importar el video
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
               selectedUri = data.getData();
                videoView.setVideoURI(selectedUri);
                videoView.start();
            }
            //GRABAR VIDEO CON LA CAMARA
            if (requestCode == GRABAR_VIDEO && resultCode == RESULT_OK) {
                selectedUri = data.getData();
                videoView.setVideoURI(selectedUri);
                videoView.start();
            }
        }


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "permission granted", Toast.LENGTH_SHORT);
            } else {
                Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT);
            }
        }
    }


    //Conseguir los permisos para el funcionamiento de la aplicacion
    private void checkPermission() {

        if (!haveStoragePermission()) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, 1);

        }



        if (ActivityCompat.shouldShowRequestPermissionRationale(this, READ_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this).setTitle("Permission needed").setMessage("Este permiso se necesita")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }



        if (!haveStorageManagePermission()) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.MANAGE_EXTERNAL_STORAGE
            }, 1);
        }

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, MANAGE_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this).setTitle("Permission needed").setMessage("Este permiso se necesita")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{MANAGE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{MANAGE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }

    public boolean haveStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23)
            return checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        else
            return true;
    }

    public boolean haveStorageManagePermission() {
        if (Build.VERSION.SDK_INT >= 23)
            return checkSelfPermission(Manifest.permission.MANAGE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        else
            return true;
    }

    /**
     * VERIFICAR PERMISOS PARA USAR LAS APLICACIONES
     */
    private void checkCameraPermission() {
        // Verificar si el permiso de cámara ha sido concedido
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Si el permiso no ha sido concedido, solicitarlo al usuario
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            startActivityForResult(takeVideoIntent, GRABAR_VIDEO);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_share) {
            compartirEnlace("https://play.google.com/store/apps/dev?id=8926389180042833552");
            return true;
        }
        if (id == R.id.action_files) {
            openFolder();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void compartirEnlace(String enlace) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, enlace);
        startActivity(Intent.createChooser(intent, "Compartir aplicacion"));
    }

    public void openFolder() {
        // Obtén la ruta de la carpeta que deseas abrir
        String folderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize";

        // Crea un objeto File con la ruta de la carpeta
        File folder = new File(folderPath);

// Verifica si la carpeta existe y es un directorio
        if (folder.exists() && folder.isDirectory()) {
            // Crea un intent para abrir la carpeta en la aplicación de administrador de archivos

            Uri uri = Uri.parse(folderPath);
            // Choose a directory using the system's file picker.

            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);

            // Optionally, specify a URI for the directory that should be opened in
            // the system file picker when it loads.
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri);
            startActivity(intent);

            // Verifica si hay aplicaciones de administrador de archivos instaladas
            if (intent.resolveActivity(getPackageManager()) != null) {
                // Abre la aplicación de administrador de archivos
                startActivity(intent);
            } else {
                // No se encontró una aplicación de administrador de archivos
                Toast.makeText(this, "Bloqueado:Movies/Pixelize, Dale acceso a la carpeta!", Toast.LENGTH_LONG).show();
            }
        }
    }

}


//diseño: #8D8D8D color botones

