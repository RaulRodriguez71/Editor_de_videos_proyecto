package com.example.pixelize;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    Uri selectedUri;
    ImageView trimvideo;
    Button uploadVideoBtn;
    VideoView videoView;
    ImageView slowmotion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Asignar las referencias a los elementos de la interfaz de usuario
        trimvideo = findViewById(R.id.trimVideo);
        uploadVideoBtn = findViewById(R.id.uploadVideoBtn);
        videoView = findViewById(R.id.videoView);
        slowmotion = findViewById(R.id.slowmoVideo);

        // Configurar el evento click para el botón de subir video
        uploadVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo();
            }
        });

        // Configurar el evento click para el elemento de recorte de video
        trimvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedUri != null) {
                    // Abrir la actividad de recorte de video y pasar la URI del video seleccionado
                    Intent intent = new Intent(MainActivity.this, TrimActivity.class);
                    intent.putExtra("uri", selectedUri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Porfavor sube el video", Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Configurar el evento click para el elemento de cámara lenta
        slowmotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedUri != null) {
                    // Abrir la actividad de cámara lenta y pasar la URI del video seleccionado
                    Intent intent = new Intent(MainActivity.this, SlowMotion.class);
                    intent.putExtra("uri", selectedUri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Porfavor sube el video", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    // Método para abrir la galería de videos
    public void openVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("viddeo/*");
        startActivityForResult(intent, 100);
    }

    private void uploadVideo() {
        /*try {
            Intent intent = new Intent();
            intent.setType("video/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Video"), REQUEST_TAKE_GALLERY_VIDEO);
        }catch (Exception e){
            e.printStackTrace();

        }*/
    }
}

//diseño: #8D8D8D color botones
/**
 * Obligar a orientacion horizontal: https://codigofacilito.com/articulos/orientacion_android
 * Quitar cabecera de aplicacion: https://es.stackoverflow.com/questions/8237/como-quitar-la-actionbar-toolbar-de-mi-aplicaci%C3%B3n-android
 * Centrar los componentes de la interfaz: https://es.stackoverflow.com/questions/516384/centrar-linearlayout-en-la-pantalla-del-dispositivo
 * Github
 * como grabar videos: https://developer.android.com/training/camera/videobasics?hl=es-419
 * Poner los frames de los videos: https://www.geeksforgeeks.org/mediametadataretriever-class-in-android-with-examples/
 * Poner un recyclerview: https://es.stackoverflow.com/questions/58343/c%C3%B3mo-crear-un-listview-en-horizontal
 * ffmpeg: https://medium.com/@eeddeellee/how-to-use-ffmpeg-in-android-37b1d732c31b
 *  comandos ffmpeg: https://gist.github.com/tayvano/6e2d456a9897f55025e25035478a3a50
 * Barras de decoracion de rangos: https://github.com/anothem/android-range-seek-bar
 * Barras de decoracion 2 : https://github.com/woxingxiao/BubbleSeekBar
 * libreria de ffmpeg para editar los videos: https://github.com/FFmpeg/FFmpeg
 * Cortar videos: https://www.youtube.com/watch?v=54iLwyZl30E
 */
