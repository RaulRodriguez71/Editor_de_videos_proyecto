package com.example.pixelize;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.Manifest;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_CAMERA_PERMISSION = 1;
    private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 2;
    Uri selectedUri;
    ImageView trimButton;
    Button uploadVideoBtn;
    VideoView videoView;
    ImageView fastButton;
    ImageView slowButton;
    ImageView filterButton;
    ImageView giroButton;
    ImageView muteButton;

    private static final String FILEPATH = "filePath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkPermission();

        // Asignar las referencias a los elementos de la interfaz de usuario
        trimButton = findViewById(R.id.trimVideo);
        uploadVideoBtn = findViewById(R.id.uploadVideoBtn);
        videoView = findViewById(R.id.videoView);
        slowButton = findViewById(R.id.slowmoVideo);
        fastButton = findViewById(R.id.fastmotion);
        filterButton = findViewById(R.id.filtrosVideo);
        giroButton = findViewById(R.id.muteBtn);


        // Configurar el evento click para el botón de subir video
        uploadVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo();
            }
        });

        // Configurar el evento click para el elemento de recorte de video
        trimButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedUri != null) {
                    // Abrir la actividad de recorte de video y pasar la URI del video seleccionado
                    Intent intent = new Intent(MainActivity.this, TrimActivity.class);
                    intent.putExtra("uri", selectedUri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Porfavor sube el video", Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Configurar el evento click para el elemento de cámara lenta
        slowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedUri != null) {
                    // Abrir la actividad de cámara lenta y pasar la URI del video seleccionado
                    Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
                    intent.putExtra("uri", selectedUri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Porfavor sube el video", Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Configurar el evento click para el elemento de cámara rapida
        fastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedUri != null) {
                    // Abrir la actividad de cámara lenta y pasar la URI del video seleccionado
                    Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
                    intent.putExtra("uri", selectedUri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Porfavor sube el video", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para abrir la galería de videos
    public void openVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("video/*");
        startActivityForResult(intent, 100);
    }

    //Que recoger de importar el video
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
                selectedUri = data.getData();
                videoView.setVideoURI(selectedUri);
                videoView.start();
            }
        }


    }

    //Que mandar si es ralentizar o acelerar
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.slowmoVideo) {
            Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
            intent.putExtra(FILEPATH, selectedUri.toString());
            intent.putExtra("type", "slowmotion");
            startActivity(intent);
        } else if (v.getId() == R.id.fastmotion) {
            Intent intent = new Intent(MainActivity.this, MotionVideoActivity.class);
            intent.putExtra(FILEPATH, selectedUri.toString());
            intent.putExtra("type", "fastmotion");
            startActivity(intent);
        }
    }

    //Conseguir los permisos para el funcionamiento de la aplicacion
    private void checkPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Si el permiso no está otorgado, solicítalo al usuario
            Toast.makeText(MainActivity.this, "No lo tiene", Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE);
        } else {
            Toast.makeText(MainActivity.this, "Permiso de external concedido", Toast.LENGTH_SHORT).show();
        }
    }
}



//diseño: #8D8D8D color botones
/**
 * Obligar a orientacion horizontal: https://codigofacilito.com/articulos/orientacion_android
 * Quitar cabecera de aplicacion: https://es.stackoverflow.com/questions/8237/como-quitar-la-actionbar-toolbar-de-mi-aplicaci%C3%B3n-android
 * Centrar los componentes de la interfaz: https://es.stackoverflow.com/questions/516384/centrar-linearlayout-en-la-pantalla-del-dispositivo
 * Github
 * como grabar videos: https://developer.android.com/training/camera/videobasics?hl=es-419
 * Poner los frames de los videos: https://www.geeksforgeeks.org/mediametadataretriever-class-in-android-with-examples/
 * Poner un recyclerview: https://es.stackoverflow.com/questions/58343/c%C3%B3mo-crear-un-listview-en-horizontal
 * ffmpeg: https://medium.com/@eeddeellee/how-to-use-ffmpeg-in-android-37b1d732c31b
 * comandos ffmpeg: https://gist.github.com/tayvano/6e2d456a9897f55025e25035478a3a50
 * Barras de decoracion de rangos: https://github.com/anothem/android-range-seek-bar
 * Barras de decoracion 2 : https://github.com/woxingxiao/BubbleSeekBar
 * libreria de ffmpeg para editar los videos: https://github.com/FFmpeg/FFmpeg
 * Cortar videos: https://www.youtube.com/watch?v=54iLwyZl30E
 */
