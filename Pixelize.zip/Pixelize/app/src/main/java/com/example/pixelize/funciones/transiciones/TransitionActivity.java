package com.example.pixelize.funciones.transiciones;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;
import com.example.pixelize.funciones.recortar.TrimActivity;

import java.io.File;
import java.util.Arrays;

public class TransitionActivity extends AppCompatActivity {

    VideoView videoView;
    ImageView imageView;
    Uri uri;
    private static final String FILEPATH = "filePath";
    File dest;
    String filePrefix;
    private String filePath;
    String original_path;
    String[] command;

    int duration;

    boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transition);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);

        Intent i = getIntent();

        if (i != null){
            String video = i.getStringExtra("uri");
            uri = uri.parse(video);

            videoView.setVideoURI(uri);
            videoView.start();

            MediaPlayer mp = MediaPlayer.create(this,Uri.parse(video));
            duration = mp.getDuration()/1000;
            mp.release();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying) {
                    imageView.setImageResource(R.drawable.boton_de_play);

                    videoView.pause();
                    isPlaying = false;
                } else {
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa);
                    isPlaying = true;
                }
            }
        });
    }

    private String getRealPathFromUri(Context context, Uri contentUri) {
        // Cursor utilizado para realizar la consulta
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public void fadeOutCommand(){
        File file = new File(Environment.getExternalStorageDirectory() + "/Pixelize");

        if (!file.exists()) {
            file.mkdir();
        }

        String FileExt = ".mp4";

        dest = new File(file, filePrefix + FileExt);

        original_path = getRealPathFromUri(getApplicationContext(), uri);

        filePath = dest.getAbsolutePath();

        command = new String[] {"-y", "-i", original_path, "-acodec", "copy", "-vf", "fade=t=in:st=0:d=5,fade=t=out:st=" + String.valueOf(duration - 5) + ":d=5", filePath};
        execFFmpegBinary(command);

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false){
            menuItem.setIcon(R.drawable.transicion);
        }
        else {
            menuItem.setIcon(R.drawable.transicion_claro);
        }
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if (item.getItemId() == R.id.Btn_funcion) {
            AlertDialog.Builder alert = new AlertDialog.Builder(TransitionActivity.this);

            LinearLayout linearLayout = new LinearLayout(TransitionActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50, 0, 50, 100);

            EditText input = new EditText(TransitionActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input, lp);
            alert.setMessage("set video name");
            alert.setTitle("videoname");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Subir", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    filePrefix = input.getText().toString();

                    fadeOutCommand();
                    finish();
                    dialogInterface.dismiss();
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }



    private void execFFmpegBinary(final String[] command) {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("porfavor espere");
        progressDialog.show();

        // Configura el callback de registro de FFmpeg
        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage logMessage) {
                Log.e(Config.TAG, logMessage.getText());
            }
        });

        // Configura el callback de estadísticas de FFmpeg
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics statistics) {
                Log.d(Config.TAG, "started command : FFmpeg" + Arrays.toString(command));
            }
        });

        // Ejecuta el comando de FFmpeg de forma asíncrona
        Long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                progressDialog.dismiss();

                // Comprueba el código de retorno de FFmpeg
                if (returnCode == RETURN_CODE_SUCCESS) {
                    // Inicia la actividad de vista previa del video
                    Intent intent = new Intent(TransitionActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                }
            }
        });
    }



}