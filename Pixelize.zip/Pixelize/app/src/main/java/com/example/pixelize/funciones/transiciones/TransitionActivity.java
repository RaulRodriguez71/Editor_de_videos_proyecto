package com.example.pixelize.funciones.transiciones;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;
import com.example.pixelize.funciones.recortar.TrimActivity;
import com.example.pixelize.funciones.velocidad.MotionVideoActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class TransitionActivity extends AppCompatActivity {

    VideoView videoView;
    ImageView imageView;
    Uri uri;
    private static final String FILEPATH = "filePath";
    File dest;
    String filePrefix;
    private String filePath;
    String original_path;
    String[] command;
    ProgressDialog progressDialog;
    CheckBox checkboxStart;
    CheckBox checkboxEnd;
    EditText editText;
    int transitionDuration = 5;


    boolean applyTransitionToStart;
    boolean applyTransitionToEnd;

    int duration;

    boolean isPlaying = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transition);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);
         checkboxStart = findViewById(R.id.checkboxStart);
         checkboxEnd = findViewById(R.id.checkboxEnd);
         editText = findViewById(R.id.editTextDuration);

        applyTransitionToStart = checkboxStart.isChecked();
        applyTransitionToEnd = checkboxEnd.isChecked();

        Intent i = getIntent();

        if (i != null){
            String video = i.getStringExtra("uri");
            uri = uri.parse(video);

            videoView.setVideoURI(uri);
            videoView.start();

            MediaPlayer mp = MediaPlayer.create(this,Uri.parse(video));
            duration = mp.getDuration()/1000;
            mp.release();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying){
                    imageView.setImageResource(R.drawable.boton_de_play_claro);
                    videoView.pause();
                    isPlaying = false;
                }else{
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa_claro);
                    isPlaying = true;
                }
            }
        });
    }

    private String getRealPathFromUri(Context context, Uri contentUri) {
        // Cursor utilizado para realizar la consulta
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public void fadeOutCommand(){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }

        String FileExt = ".mp4";

        dest = new File(file, filePrefix + FileExt);

        original_path = getRealPathFromUri(getApplicationContext(), uri);

        filePath = dest.getAbsolutePath();

        int transitionStart = 0;

        applyTransitionToStart = checkboxStart.isChecked();
        applyTransitionToEnd = checkboxEnd.isChecked();
        //Insertar la transicion al principio del video
        if (applyTransitionToStart && !applyTransitionToEnd) {
            // Aplicar la transición al principio del video
            command = new String[]{"-y", "-i", original_path, "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-vf", "fade=t=in:st=0:d=" + transitionDuration + ",fade=t=out:st=" + transitionDuration + ":d=" + transitionDuration + ":alpha=1", "-c:a", "aac", "-strict", "-2", filePath};

        }
        //Insertar la transicion al final del video
        else if (!applyTransitionToStart && applyTransitionToEnd) {
            // Aplicar la transición al final del video
            int videoDuration = obtenerDuracionVideo(original_path);
            transitionStart = videoDuration - transitionDuration;
            // Verificar si la duración de la transición es mayor que la duración del video
            if (transitionStart < 0) {
                transitionStart = 0; // Establecer el inicio de la transición en 0
                transitionDuration = videoDuration / 2; // Ajustar la duración de la transición
            }
            command = new String[]{"-y", "-i", original_path, "-vf", "fade=type=in:duration=1,fade=type=out:duration=1:start_time=" + (transitionStart), "-c:v", "libx264", "-c:a", "aac", "-strict", "-2", "-shortest", filePath};

        }
        //Insertar la transicion al principio y al final del video
    else if (applyTransitionToStart && applyTransitionToEnd) {
            // Aplicar la transición tanto al principio como al final del video
            int videoDuration = obtenerDuracionVideo(original_path);
            transitionStart = videoDuration - transitionDuration;
            // Verificar si la duración de la transición es mayor que la duración del video
            if (transitionStart < 0) {
                transitionStart = 0; // Establecer el inicio de la transición en 0
                transitionDuration = videoDuration / 2; // Ajustar la duración de la transición
            }

            System.out.println("/////////////"+transitionStart);
            command = new String[]{"-y", "-i", original_path, "-vf", "fade=t=in:st=0:d=" + transitionDuration + ",fade=t=out:st=" + (videoDuration - transitionDuration) + ":d=" + transitionDuration + ":alpha=1,reverse,fade=t=in:st=0:d=" + transitionDuration + ",fade=t=out:st=" + (videoDuration - transitionDuration) + ":d=" + transitionDuration + ":alpha=1,reverse", "-c:v", "libx264", "-c:a", "aac", "-strict", "-2", "-shortest", filePath};

        }

        System.out.println("BOOLEAN:" + applyTransitionToStart);
        execFFmpegBinary(command);

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker, menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false){
            menuItem.setIcon(R.drawable.transicion);
        }
        else {
            menuItem.setIcon(R.drawable.transicion_claro);
        }
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        applyTransitionToStart = checkboxStart.isChecked();
        applyTransitionToEnd = checkboxEnd.isChecked();

        if (editText.getText() == null) editText.setText("5");
//
        if (item.getItemId() == R.id.Btn_funcion && (applyTransitionToStart == true || applyTransitionToEnd == true)) {


            AlertDialog.Builder alert = new AlertDialog.Builder(TransitionActivity.this);

            LinearLayout linearLayout = new LinearLayout(TransitionActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50, 0, 50, 100);

            EditText input = new EditText(TransitionActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input, lp);
            alert.setMessage("Introduce un nombre para el video editado");
            alert.setTitle("Video editado");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Editar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    if (!TextUtils.isEmpty(input.getText())) {
                        filePrefix = input.getText().toString();

                        fadeOutCommand();
                        dialogInterface.dismiss();
                    }
                    else{
                        Toast.makeText(TransitionActivity.this, "El nombre del archivo no puede estar vacío", Toast.LENGTH_SHORT).show();
                    }
                }

            });
            alert.show();
        }
        else{
            Toast.makeText(this, "Debes introducir en algun momento del video la transición", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }



    private void execFFmpegBinary(final String[] command) {

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Por favor, espere");
        progressDialog.show();

        // Configura el callback de registro de FFmpeg
        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(LogMessage logMessage) {
                Log.e(Config.TAG, logMessage.getText());
            }
        });

        // Configura el callback de estadísticas de FFmpeg
        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics statistics) {
                Log.d(Config.TAG, "started command : FFmpeg" + Arrays.toString(command));
            }
        });

        progressDialog.show();

        // Ejecuta el comando de FFmpeg de forma asíncrona
        Long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                progressDialog.dismiss();

                // Comprueba el código de retorno de FFmpeg
                if (returnCode == RETURN_CODE_SUCCESS) {
                    // Inicia la actividad de vista previa del video
                    finish();
                    Intent intent = new Intent(TransitionActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH, filePath);
                    startActivity(intent);
                }else if (returnCode == RETURN_CODE_CANCEL){
                    Log.e(Config.TAG,"El commando ha sido cancelado por el usuario");
                }
                else{
                    Log.e(Config.TAG,"La ejecucion del comando ha fallado");
                }
            }
        });
    }



    public int obtenerDuracionVideo(String videoPath) {
        int duration = 0;

        try {
            // Crear un objeto MediaMetadataRetriever
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();

            // Establecer la fuente del video
            retriever.setDataSource(videoPath);

            // Obtener la duración del video en microsegundos
            String durationString = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);

            // Convertir la duración a milisegundos
            long durationMicroSec = Long.parseLong(durationString);
            duration = (int) (durationMicroSec / 1000);

            // Liberar el objeto MediaMetadataRetriever
            retriever.release();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return duration;
    }


    private int convertirDuracionASegundos(String durationString) {
        int durationInSeconds = 0;

        try {
            // Dividir la duración en horas, minutos, segundos
            String[] parts = durationString.split(":");

            // Convertir a segundos
            int hours = Integer.parseInt(parts[0]);
            int minutes = Integer.parseInt(parts[1]);
            int seconds = Integer.parseInt(parts[2].split("\\.")[0]);

            durationInSeconds = hours * 3600 + minutes * 60 + seconds;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        return durationInSeconds;
    }


}