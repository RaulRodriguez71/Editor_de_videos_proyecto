package com.example.pixelize.funciones.mostrar;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.MediaController;
import android.widget.VideoView;

import com.example.pixelize.R;

public class PreviewActivity extends AppCompatActivity {

    VideoView videoView;

    private static final String FILEPATH = "filePath";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);





        videoView = findViewById(R.id.videoView);

        String filePath = getIntent().getStringExtra(FILEPATH);

        videoView.setVideoURI(Uri.parse(filePath));

        MediaController mediaController = new MediaController(this);

        videoView.setMediaController(mediaController);

        videoView.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Mostrar el diálogo de confirmación
            showConfirmationDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar salida");
        builder.setMessage("¿Estás seguro de que deseas salir?");

        // Agregar botón "Aceptar"
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // El usuario confirmó, puedes realizar la acción de salida
                finish();
            }
        });

        // Agregar botón "Cancelar"
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // El usuario canceló, no se realiza ninguna acción
            }
        });

        // Mostrar el diálogo
        builder.create().show();
    }

}