package com.example.pixelize.funciones.silenciar;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.example.pixelize.MainActivity.oscuro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.example.pixelize.R;
import com.example.pixelize.funciones.mostrar.PreviewActivity;

import java.io.File;
import java.util.Arrays;


public class VideoSoundActivity extends AppCompatActivity {
    private Uri uri;
    private static final String FILEPATH = "filePath";
    File dest;
    String filePrefix;
    private String filePath;
    String original_path;
    String[] command;
    boolean isPlaying = false;
    VideoView videoView;
    ImageView imageView;
    ProgressDialog progressDialog;
    ImageView sound;
    SeekBar seekBar;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_sound);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        VideoSoundActivity.this.setTitle("VOLUME VIDEO");
        videoView = findViewById(R.id.videoView);
        imageView = findViewById(R.id.imageView);
        sound = findViewById(R.id.imageSound);
        seekBar = findViewById(R.id.seekBar);
        textView = findViewById(R.id.textView);

        Intent intent = getIntent();
        if (intent != null){
            String revVideo = intent.getStringExtra("uri");
            uri = Uri.parse(revVideo);
            videoView.setVideoURI(uri);
            isPlaying = true;
            videoView.start();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPlaying){
                    imageView.setImageResource(R.drawable.boton_de_play_claro);
                    videoView.pause();
                    isPlaying = false;
                }else{
                    videoView.start();
                    imageView.setImageResource(R.drawable.pausa_claro);
                    isPlaying = true;
                }
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Actualizar el texto del TextView con el valor actual del SeekBar
                textView.setText(String.valueOf(progress));

                if(progress == 0){
                    sound.setImageResource(R.drawable.mute_claro);
                }
                else{
                    sound.setImageResource(R.drawable.sonido_claro);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Método requerido, no es necesario implementar nada aquí
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Método requerido, no es necesario implementar nada aquí
            }
        });

    }

    public void muteVideoCommand(){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + "/Pixelize");

        // Si la carpeta no existe, se crea
        if (!file.exists()) {
            file.mkdir();
        }
        String FileExt = ".mp4";

        dest = new File(file,filePrefix + FileExt);
        original_path = getRealPathFromUri(getApplicationContext(),uri);

        filePath = dest.getAbsolutePath();

       // command = new String[]{"-i",original_path,"-c","copy","-an",filePath}; Mutear directamente

        // Calcular el valor del volumen según el progreso
        float volume = (float) seekBar.getProgress() / 100.0f;

        // Construir el comando de FFmpeg
        String[] command = new String[]{"-y", "-i", original_path, "-af", "volume=" + volume, "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-c:a", "aac", "-strict", "-2", filePath};

        execFFMpegBinary(command);



    }

    private String getRealPathFromUri(Context context,Uri contentUri){
        Cursor cursor = null;

        try {
            // Columnas a consultar en la base de datos de contenido
            String[] proj = {MediaStore.Images.Media.DATA};

            // Realiza una consulta en el proveedor de contenido usando la URI y las columnas especificadas
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);

            // Obtiene el índice de la columna de la ruta del archivo
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            // Mueve el cursor al primer registro
            cursor.moveToFirst();

            // Obtiene la ruta del archivo a partir del valor de la columna especificada
            return cursor.getString(column_index);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            // Cierra el cursor para liberar los recursos
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_picker,menu);
        MenuItem menuItem = menu.findItem(R.id.Btn_funcion);
        if (oscuro == false){
            menuItem.setIcon(R.drawable.volumen);
        }
        else {
            menuItem.setIcon(R.drawable.volumen_claro);
        }

        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if (item.getItemId() == R.id.Btn_funcion){
            AlertDialog.Builder alert = new AlertDialog.Builder(VideoSoundActivity.this);

            LinearLayout linearLayout = new LinearLayout(VideoSoundActivity.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);

            lp.setMargins(50,0,50,100);

            EditText input = new EditText(VideoSoundActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.TOP| Gravity.START);
            input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

            linearLayout.addView(input,lp);
            alert.setMessage("Introduce un nombre para el video editado");
            alert.setTitle("Video editado");
            alert.setView(linearLayout);
            alert.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    dialogInterface.dismiss();
                }
            });

            alert.setPositiveButton("Editar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    if (!TextUtils.isEmpty(input.getText())) {
                        filePrefix = input.getText().toString();
                        muteVideoCommand();
                        dialogInterface.dismiss();
                }
                    else{
                    Toast.makeText(VideoSoundActivity.this, "El nombre del archivo no puede estar vacío", Toast.LENGTH_SHORT).show();
                }
                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }


    private void execFFMpegBinary(String[] command){
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Por favor, espere");
        progressDialog.show();

        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics newStatistics) {
                Log.e(Config.TAG,String.format("frame: %d,time: %d",newStatistics.getVideoFrameNumber(),newStatistics.getTime()));
                Log.d(TAG,"Started command : ffmpeg " + Arrays.toString(command));

            }
        });
        Log.d(TAG,"Started command : ffmpeg " + Arrays.toString(command));
        progressDialog.show();

        long executionId = FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS){
                    Log.d(Config.TAG,"finished command: ffmpeg" + Arrays.toString(command));
                    finish();
                    Intent intent = new Intent(VideoSoundActivity.this, PreviewActivity.class);
                    intent.putExtra(FILEPATH,filePath);
                    startActivity(intent);
                }else if (returnCode == RETURN_CODE_CANCEL){
                    Log.e(Config.TAG,"Async command execution canceled by user");
                }else{
                    Log.e(Config.TAG,String.format("Async command execution failed with returncode = %d", returnCode));
                }

            }
        });
    }

}